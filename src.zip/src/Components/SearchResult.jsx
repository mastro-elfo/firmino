import React, {Component} from 'react';
import {withRouter} from 'react-router-dom';

import {withStyles} from '@material-ui/core/styles';
import List from '@material-ui/core/List';
import ListSubheader from '@material-ui/core/ListSubheader';
import ListItem from '@material-ui/core/ListItem';
import ListItemIcon from '@material-ui/core/ListItemIcon';
import ListItemText from '@material-ui/core/ListItemText';

import {prefix} from 'prefix-si';

function SearchResult (props) {
	const {search, time, result, limit, history: {push}, classes} = props;

	return (
		<List
			subheader={(
				!!search &&
				<ListSubheader
					className={classes.ListSubheader}>
					{result.length} {result.length === 1 ? 'risultato' : 'risultati'} in {prefix(time /1000, 's')}
				</ListSubheader>
			)}>
			{
				result.slice(0, limit).map((item, i) => (
					<ListItem
						key={i}
						button
						onClick={()=>{push(item.link)}}>
						{
							item.icon &&
							<ListItemIcon>
								{item.icon}
							</ListItemIcon>
						}
						<ListItemText
							primary={item.primary}
							secondary={item.secondary}/>
						{
							item.secondaryIcon &&
							<ListItemIcon>
								{item.secondaryIcon}
							</ListItemIcon>
						}
					</ListItem>
				))
			}
		</List>
	);
}

SearchResult.defaultProps = {
	time: 0,
	result: [],
	search: '',
	limit: 5
};

const styles = theme => ({
	ListSubheader: {
		background: 'white'
	}
});

export default withRouter(withStyles(styles)(SearchResult));
