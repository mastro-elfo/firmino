import {validate, toIsbn13, hyphenate, dehyphenate} from 'beautify-isbn';

export function anyToIsbn13 (any) {
	any = any.toUpperCase();
	if(validate(any)){
		const dehyph = dehyphenate(any);
		if(dehyph.length === 10) {
			return hyphenate(toIsbn13(dehyph));
		}
		else {
			return hyphenate(dehyph);
		}
	}
	else {
		return any;
	}
}
