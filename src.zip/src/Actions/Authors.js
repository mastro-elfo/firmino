import Collection from './Collection';

export default class Authors extends Collection {
	constructor(){
		super('authors');
	}
}
