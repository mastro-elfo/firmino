import Collection from './Collection';

export default class Positions extends Collection {
	constructor(){
		super('positions');
	}
}
