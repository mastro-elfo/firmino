
import Collection from './Collection';
import uuid from 'uuid/v1';

export default class Record {
	constructor(collection) {
		this.collection = new Collection(collection);
	}

	Create = (record) => {
		// TODO: don't need a Promise here
		return new Promise((resolve, reject) => {
			this.collection.Read()
			.then(records => {
				record.id = uuid();
				records.push(record);
				this.collection.Update(records)
				.then(() => resolve(record))
				.catch(err => reject(err));
			})
			.catch(err => reject(err));
		});
	}

	Read = (id) => {
		// TODO: don't need a Promise here
		return new Promise((resolve, reject) => {
			this.collection.Read()
			.then(records => {
				const record = records.find(item => item.id === id);
				if(record){
					resolve(record);
				}
				else {
					reject(new Error('Record not found', id));
				}
			})
			.catch(err => reject(err));
		});
	}

	// TODO: Don't need to pass id
	Update = (id, record) => {
		// TODO: don't need a Promise here
		return new Promise((resolve, reject) => {
			this.collection.Read()
			.then(records => {
				const index = records.findIndex(item => item.id === id);
				if(index !== -1){
					records[index] = {
						...records[index],
						...record
					};
					this.collection.Update(records)
					.then(() => resolve())
					.catch(err => reject(err));
				}
				else {
					reject(new Error('Record not found'));
				}
			})
			.catch(err => reject(err));
		});
	}

	Delete = (id) => {
		// TODO: don't need a Promise here
		return new Promise((resolve, reject) => {
			this.collection.Read()
			.then(records => {
				let index = records.findIndex(item => item.id === id);
				if(index !== -1){
					records.splice(index, 1);
					this.collection.Update(records)
					.then(() => resolve())
					.catch(err => reject(err));
				}
			})
			.catch(err => reject(err));
		});
	}
}
