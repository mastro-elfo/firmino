
import {
	Create as FSCreate,
	Read as FSRead,
	Update as FSUpdate,
	Delete as FSDelete,
	Stats as FSStats
} from './Filesystem';

export function Create (filename, json) {
	json = json || {};
	try {
		return FSCreate(filename, JSON.stringify(json));
	}
	catch(err){
		// TODO: Promise.reject(err)
		new Promise((resolve, reject)=>reject(err));
	}
}

export function Read (filename) {
	return FSRead(filename)
	// TODO: Don't need Promise here
		.then(content => new Promise((resolve, reject) => {
			try {
				const json = JSON.parse(content);
				resolve(json);
			}
			catch(err) {
				reject(err);
			}
		}));
}

export function Update (filename, json) {
	try {
		return FSUpdate(filename, JSON.stringify(json));
	}
	catch(err){
		// TODO: Promise.reject(err)
		new Promise((resolve, reject)=>reject(err));
	}
}

export function Delete (filename) {
	return FSDelete(filename);
};

export function Stats (filename) {
	return FSStats(filename);
};
