import Collection from './Collection';

export default class Users extends Collection {
	constructor(){
		super('users');
	}
}
